# -*- coding: utf-8 -*-

class HelpOptions:
    Prefix = '╭───「 Help 」'
    Header = '├──「 %s 」'
    Footer = '╰───「 Hello World 」'
    Left = '├≽ '
    Num = ''
    Doc = True
    DocSep = '\n│ • '
    ArgsSep = '/'
    ArgsLeft = '<'
    ArgsRight = '>'